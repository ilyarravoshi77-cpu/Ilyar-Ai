import React from 'react';
import {Composition} from 'remotion';
import {IlyarAI} from './Video';

export const RemotionRoot: React.FC = () => <>
  <Composition id="IlyarAI" component={IlyarAI} durationInFrames={1620} fps={30} width={2160} height={3840} />
</>;
