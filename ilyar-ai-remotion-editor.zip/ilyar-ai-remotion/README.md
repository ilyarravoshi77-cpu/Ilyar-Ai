# ILYAR AI — Remotion Motion Graphics

A 54-second vertical Swiss International Style motion-graphics project. No presenter, stock footage, generated faces, or 3D characters.

## Specs
- 2160 × 3840 (4K vertical), 30 fps, 1620 frames / 54 seconds
- 8 editorial scenes, Persian kinetic typography, grid system, red `#E53935` accent
- Remotion Studio editor + H.264 4K render scripts

## Run in GitHub Codespaces
1. Upload this folder to a GitHub repository (or upload the ZIP and extract it in a Codespace).
2. Open the repository on GitHub, choose **Code → Codespaces → Create codespace on main**.
3. In the Codespaces terminal run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the forwarded port shown by Codespaces (Remotion Studio usually uses port 3000).
5. Select the `IlyarAI` composition to preview and edit.

## Render

```bash
npm run render:4k
```

Output: `out/ilyar-ai-4k.mp4`.

## Edit the video
- Scene order and timing are in `src/Video.tsx`, in the `Sequence` list at the bottom.
- Each scene is a React component (`Scene1` … `Scene8`). Edit Persian copy, colors, geometry, and animation timing there.
- Global palette and typography tokens are at the top of `src/Video.tsx`.
- Composition dimensions, fps, and duration are in `src/Root.tsx`.

## Notes
- The project is configured for a 54-second cut. The final brand lockup holds for the last 3 seconds.
- Persian type uses a system-font fallback stack. For consistent rendering, install/use Vazirmatn or Noto Sans Arabic in the render environment if your platform does not have a Persian-capable font.
- Sound design is intentionally left as an editable layer to avoid bundling unlicensed music. Add a licensed ambient track and subtle UI/mechanical foley in Remotion when ready.
